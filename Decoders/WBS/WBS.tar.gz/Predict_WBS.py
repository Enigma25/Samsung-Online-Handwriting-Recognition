from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import time
import numpy as np
import tensorflow as tf
import model_blstm as model_blstm
import editdistance
import pdb
from tensorflow.saved_model import tag_constants

FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_string('data_dir', './',"data directory")
tf.app.flags.DEFINE_string('checkpoints_dir', '../checkpoints/',"training checkpoints directory")
tf.app.flags.DEFINE_string('log_dir1', '../train_log/',"summary directory")
##################################################TBC
tf.app.flags.DEFINE_string('restore_path', '../checkpoints/model_3_jan/model.ckpt-19831',"path of saving model eg: ../checkpoints/model.ckpt-5")
##################################################TBC
tf.app.flags.DEFINE_integer('batch_size', 1,"mini-batch size")
tf.app.flags.DEFINE_integer('total_epoches', 300,"total training epoches")
tf.app.flags.DEFINE_integer('hidden_size', 128,"size of LSTM hidden memory")
tf.app.flags.DEFINE_integer('num_layers', 2,"number of stacked blstm")
tf.app.flags.DEFINE_integer("input_dims", 10,"input dimensions")
##################################################TBC Done
tf.app.flags.DEFINE_integer("num_classes", 80,"num_labels + 1(blank)")
tf.app.flags.DEFINE_integer('save_freq', 5,"ephoches of frequency of saving model")
tf.app.flags.DEFINE_float('learning_rate', 0.001,"learning rate of RMSPropOptimizer")
tf.app.flags.DEFINE_float('decay_rate', 0.99,"decay rate of RMSPropOptimizer")
tf.app.flags.DEFINE_float('momentum', 0.9,"momentum of RMSPropOptimizer")
tf.app.flags.DEFINE_float('max_length', 1940,"pad to same length")
tf.app.flags.DEFINE_integer('label_pad', 63,"label pad size")
tf.app.flags.DEFINE_boolean('if_lowercase_only', False,"if letter table only contain lowercase")




##################################################TBC Done
if FLAGS.if_lowercase_only:
    pass
else:
    letter_table = [' ','!','"','#','&',"'","(",")","*","+",',',"-",".","/","0","1","2","3","4","5","6","7","8","9",":",";","?",'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p','q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',"<b>"]


class ModelConfig(object):
    """
    testing config
    """

    def __init__(self):
        self.data_dir = FLAGS.data_dir
        self.checkpoints_dir = FLAGS.checkpoints_dir
        self.log_dir1 = FLAGS.log_dir1
        self.restore_path = FLAGS.restore_path
        self.batch_size = FLAGS.batch_size
        self.total_epoches = FLAGS.total_epoches
        self.hidden_size = FLAGS.hidden_size
        self.num_layers = FLAGS.num_layers
        self.input_dims = FLAGS.input_dims
        self.num_classes = FLAGS.num_classes
        self.save_freq = FLAGS.save_freq
        self.learning_rate = FLAGS.learning_rate
        self.decay_rate = FLAGS.decay_rate
        self.momentum = FLAGS.momentum
        self.max_length = FLAGS.max_length
        self.label_pad = FLAGS.label_pad





def split_random(input_data,target_data,random_indices_fn):
    
    # input_data: raw touch points from data.npy
    # target_data: dictionary received from dense.npy
    # isNewModel: bool to denote random_shuffling should be new or load from previous
    # returns the train+validate set together which can be divided later in the code 	    
    ## if New Model is to be created generate random permutation with the name of the date as random_indices_*date*.npy
    

    random_indices = np.load(random_indices_fn,None,True,True,'ASCII')
    ## extracts dense and length of the labels from the dictionary
    label_data = target_data['dense'].astype(np.int32)
    label_data_length = target_data['length'].astype(np.int32)    
    ## assuming a test set of 25% of total data --> 75% train+validate dataset
    random_indices_test = random_indices[(len(random_indices)*76)//100:]
    input_data_new = []
    label_data_new = []
    label_data_length_new = []
    ## pick those elements from the whole dataset, which correspond to the 75% of randomly generated indices
    for i in random_indices_test:
        input_data_new.append(input_data[i])
        label_data_new.append(label_data[i])
        label_data_length_new.append(label_data_length[i])	
    ## Returns a 3 tuple of input_data , labels, label_lengths
    return (np.asarray(input_data_new),np.asarray(label_data_new),np.asarray(label_data_length_new))




def predict():
    graph1 = tf.Graph()
    with graph1.as_default():
        
        # config setting
        config = ModelConfig()
        # load data
        input_data = np.load(FLAGS.data_dir + 'data.npy',None,True,True,'ASCII')
        target_data = np.load(FLAGS.data_dir + 'dense.npy',None,True,True,'ASCII').item()
        valid_label = target_data['dense'].astype(np.int32)
        valid_label_length = target_data['length'].astype(np.int32)
        ##################################################TBC Call split random	
        input_data,test_label,test_label_length = split_random(input_data,target_data,'test_file.npy')
        #print(valid_label.shape)
        # label_seq_len = target_data['length'].astype(np.int32)
        seq_len_list = []
        for _, v in enumerate(input_data):
            seq_len_list.append(v.shape[0])
        test_seq_len = np.array(seq_len_list).astype(np.int32)
        k = np.argmax(seq_len_list)
        #max_length = input_data[k].shape[0]
        max_length = 1940 
        #print(input_data.shape)
        # padding each textline to maximum length -> max_length (1940)
        padded_input_data = []
        for _, v in enumerate(input_data):
            residual = max_length - v.shape[0]
            padding_array = np.zeros([residual, FLAGS.input_dims])
            #print('hello',padding_array.shape)
            padded_input_data.append(np.concatenate([v, padding_array], axis=0))
            #print(padded_input_data.shape)
        test_data = np.array(padded_input_data)
        #print('hi',valid_data.shape)
        model = model_blstm.HWRModel(config, graph1)
        saver = tf.train.Saver()
        with tf.Session(graph=graph1) as sess:
            print('Restoring ...')
            #saver = tf.train.import_meta_graph('./checkpoints/model.ckpt-1.meta')
            saver.restore(sess,FLAGS.restore_path)
            print('OK')

            input_data_ph = graph1.get_tensor_by_name('input_data:0')
            seq_len_ph = graph1.get_tensor_by_name('sequence_lenth:0')
            label_data_ph = graph1.get_tensor_by_name('label_data:0')

            ##################################################TBC 0:1 --> (i:i+1)
            #pdb.set_trace()
            total_error = 0
            total_length = 0
            for i in range(len(test_data)-1):
                val = test_data[i:i+1]
                seq = test_seq_len[i:i+1]
                lab = test_label[i:i+1]
                print("i: ",i)
                ##################################################TBC test_label_length[i]
                visual_target_length = test_label_length[i]
                start_time = time.time()
                predict = model.predict2(sess, val, seq, lab)
                str_decoded = predict[:visual_target_length]
                val_original = ''.join([letter_table[x] for x in lab[0,:visual_target_length]])
                end_time = time.time()
                print('Original val: %s' % val_original)
                print('Decoded  val: %s' % str_decoded)
                print(end_time-start_time)
                d = editdistance.eval(val_original,str_decoded)
                total_error += d
                total_length += visual_target_length
                print(d)
                print("CER: ",total_error/total_length)

            print("CER FINAL: ",total_error/total_length)
                
                
if __name__=="__main__":
    predict()


