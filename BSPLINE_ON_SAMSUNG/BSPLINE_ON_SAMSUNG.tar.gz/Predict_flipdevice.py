from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import time
import numpy as np
import tensorflow as tf
import model_blstm

from tensorflow.saved_model import tag_constants

FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_string('data_dir', './',"data directory")
tf.app.flags.DEFINE_string('checkpoints_dir', '../checkpoints/',"training checkpoints directory")
tf.app.flags.DEFINE_string('log_dir1', '../train_log/',"summary directory")
tf.app.flags.DEFINE_string('restore_path', './checkpoints/model.ckpt-3',"path of saving model eg: ../checkpoints/model.ckpt-5")
tf.app.flags.DEFINE_integer('batch_size', 1,"mini-batch size")
tf.app.flags.DEFINE_integer('total_epoches', 300,"total training epoches")
tf.app.flags.DEFINE_integer('hidden_size', 128,"size of LSTM hidden memory")
tf.app.flags.DEFINE_integer('num_layers', 2,"number of stacked blstm")
tf.app.flags.DEFINE_integer("input_dims", 10,"input dimensions")
tf.app.flags.DEFINE_integer("num_classes", 69,"num_labels + 1(blank)")
tf.app.flags.DEFINE_integer('save_freq', 5,"ephoches of frequency of saving model")
tf.app.flags.DEFINE_float('learning_rate', 0.001,"learning rate of RMSPropOptimizer")
tf.app.flags.DEFINE_float('decay_rate', 0.99,"decay rate of RMSPropOptimizer")
tf.app.flags.DEFINE_float('momentum', 0.9,"momentum of RMSPropOptimizer")
tf.app.flags.DEFINE_float('max_length', 1940,"pad to same length")
tf.app.flags.DEFINE_integer('label_pad', 63,"label pad size")
tf.app.flags.DEFINE_boolean('if_lowercase_only', False,"if letter table only contain lowercase")

if FLAGS.if_lowercase_only:
    letter_table = [' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'ga', 'h', 'i', 'j', 'k', 'km', 'l', 'm', 'n', 'o', 'p', 'pt',
                    'q', 'r', 's', 'sc', 'sp', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '<b>']
else:
    letter_table = [' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
                    'g', 'ga', 'h', 'i', 'j', 'k', 'km', 'l', 'm', 'n', 'o', 'p', 'pt', 'q', 'r', 's', 'sc', 'sp', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '<b>']


class ModelConfig(object):
    """
    testing config
    """

    def __init__(self):
        self.data_dir = FLAGS.data_dir
        self.checkpoints_dir = FLAGS.checkpoints_dir
        self.log_dir1 = FLAGS.log_dir1
        self.restore_path = FLAGS.restore_path
        self.batch_size = FLAGS.batch_size
        self.total_epoches = FLAGS.total_epoches
        self.hidden_size = FLAGS.hidden_size
        self.num_layers = FLAGS.num_layers
        self.input_dims = FLAGS.input_dims
        self.num_classes = FLAGS.num_classes
        self.save_freq = FLAGS.save_freq
        self.learning_rate = FLAGS.learning_rate
        self.decay_rate = FLAGS.decay_rate
        self.momentum = FLAGS.momentum
        self.max_length = FLAGS.max_length
        self.label_pad = FLAGS.label_pad
        #self.if_valid_vr = FLAGS.if_valid_vr

  

def predict():
    graph1 = tf.Graph()
    with graph1.as_default():
        
        # config setting
        config = ModelConfig()
        # load data
        input_data = np.load(FLAGS.data_dir + 'data_flipdevice.npy',None,True,True,'ASCII')
        #target_data = np.load(FLAGS.data_dir + 'dense.npy',None,True,True,'ASCII').item()
        #valid_label = target_data['dense'].astype(np.int32)
        #valid_label_length = target_data['length'].astype(np.int32)
        #print(valid_label.shape)
        # label_seq_len = target_data['length'].astype(np.int32)
        seq_len_list = []
        for _, v in enumerate(input_data):
            seq_len_list.append(v.shape[0])
        valid_seq_len = np.array(seq_len_list).astype(np.int32)
        k = np.argmax(seq_len_list)
        #max_length = input_data[k].shape[0]
        max_length = 1940 
        #print(input_data.shape)
        # padding each textline to maximum length -> max_length (1940)
        padded_input_data = []
        for _, v in enumerate(input_data):
            residual = max_length - v.shape[0]
            padding_array = np.zeros([residual, FLAGS.input_dims])
            #print('hello',padding_array.shape)
            padded_input_data.append(np.concatenate([v, padding_array], axis=0))
            #print(padded_input_data.shape)
        valid_data = np.array(padded_input_data)
        #print('hi',valid_data.shape)
        model = model_blstm.HWRModel(config, graph1)
        saver = tf.train.Saver()
        with tf.Session(graph=graph1) as sess:
            print('Restoring ...')
            #saver = tf.train.import_meta_graph('./checkpoints/model.ckpt-1.meta')
            saver.restore(sess,FLAGS.restore_path)
            print('OK')

            #input_data_ph = graph1.get_tensor_by_name('input_data:0')
            #seq_len_ph = graph1.get_tensor_by_name('sequence_lenth:0')
 #           label_data_ph = graph1.get_tensor_by_name('label_data:0')
#            decoded_output = graph1.get_tensor_by_name('decoder/CTCGreedyDecoder:0')
            #print(valid_data.shape)
            #print(valid_seq_len.shape)
            #print(valid_label.shape)

            val = valid_data[0:1]
            seq = valid_seq_len[0:1]
#            lab = valid_label[0:1]
            #print(val.shape,seq.shape,lab.shape)
            #val_new = np.tile(val,(128,1,1))
            #seq_new = np.tile(seq,128)
            #lab_new = np.tile(lab,(128,1))
            #print(val_new.shape, seq_new.shape, lab_new.shape)

 #           visual_target_length = valid_label_length[0]
            predict = model.predict(sess, val, seq)
            str_decoded = ''.join([letter_table[x] for x in np.asarray(predict.values[:])])
 #           val_original = ''.join([letter_table[x] for x in lab[0,:visual_target_length]])
            end_time = time.time()
 #           print('Original val: %s' % val_original)
            print('Decoded  val: %s' % str_decoded)

            #decoded_seq = sess.run([decoded_output],feed_dict={input_data_ph:val, seq_len_ph:seq, label_data_ph:lab})
            #print(decoded_seq)
            #visual_target_length = valid_label_length[0]
            #print(visual_target_length)
            #val_original = ''.join([letter_table[x] for x in val])
            #print('Original val: %s' % val_original)   
            #str_decoded = ''.join([letter_table[x] for x in np.asarray(decoded_seq[:visual_target_length])])
            #val_original = ''.join([letter_table[x] for x in lab])
            #print('Original val: %s' % val_original)
            #print('Decoded  val: %s' % str_decoded)
                


