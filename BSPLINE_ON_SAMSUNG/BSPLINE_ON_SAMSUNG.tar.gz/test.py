import os
import Preprocessor as p
import Read as r
import Predict_flipdevice as pr
#import Predict as pr
#FILE_PATH = os.path.dirname(os.path.realpath(__file__))
#DATA_PATH = os.path.join(FILE_PATH, "data/")
#LABEL_DATA_PATH = os.path.join(DATA_PATH, "ascii/")
#STROKES_DATA_PATH = os.path.join(DATA_PATH, "lineStrokes/")

print("Intiaizing the test")
print("preprocessing the strokes to form input features")

#print(FILE_PATH)
#print(STROKES_DATA_PATH)
#p.preprocess(STROKES_DATA_PATH,LABEL_DATA_PATH)

#print("Dense label representation created")
#r.create_dense()

print("Predicting")
pr.predict()
