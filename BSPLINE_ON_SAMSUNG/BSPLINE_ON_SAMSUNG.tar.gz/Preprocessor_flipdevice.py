from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import re
import math
import os
import xml.etree.ElementTree as ET
import matplotlib.pyplot as plta

scale_newy = 1376/811
scale_newx = 3512/783
def get_writing_direction(x_sp,y_sp,writing_sin,writing_cos):
    # writing direction
    w_sin_stroke = []
    w_cos_stroke = []
    for idx, x_v in enumerate(x_sp):
        y_v = y_sp[idx]
        slope = np.sqrt(x_v * x_v + y_v * y_v)
        if slope != 0:
            w_sin_stroke.append(y_v / slope)
            w_cos_stroke.append(x_v / slope)
        else:
            w_sin_stroke.append(0)
            w_cos_stroke.append(1)
    writing_sin += w_sin_stroke
    writing_cos += w_cos_stroke
    return writing_sin,writing_cos



def get_pen_up_down(x_point,pen_up_list):
    # pen up and down
    pen_up = [1] * (len(x_point) - 1) + [0]
    pen_up_list += pen_up
    return pen_up_list
def normalized_x_y(x_list,y_list,e_tree):
    x_cor, y_cor = np.copy(x_list),np.copy(y_list)
    #cor_dial = e_tree.findall('WhiteboardDescription/DiagonallyOppositeCoords')[0]
    x_max,y_max = max(x_list), max(y_list)
    x_min, y_min = min(x_list), min(y_list)
    scale = 1.0 / (y_max - y_min)
    # normalize x_cor , y_cor
    x_cor, y_cor = (x_cor - x_min) * scale, (y_cor - y_min) * scale
    return x_cor,y_cor,x_min,x_max,y_min,y_max,scale

def get_timestamp(e_tree,x_list,y_list,time_stamp):
    first_time = 0.0
    print(first_time)
    
    for atype in e_tree.findall('StrokeSet/Stroke/Point'):
        
        x_list.append(int(atype.get('x'))*scale_newx)
        y_list.append(int(atype.get('y'))*scale_newy)
        if len(time_stamp) == 0:
            first_time = float(atype.get('time'))
            time_stamp.append(0.0)
        else:
            time_stamp.append(
            float(atype.get('time')) - first_time)
    return x_list,y_list,time_stamp

def preprocess(STROKES_DATA_PATH):
    text_line_data_all = []
    for path_1, _, files in os.walk(STROKES_DATA_PATH):
        files = sorted(files)
        print(files)
        for file_name in files:  # TextLine files
            #label
            # truncate out .xml
            #text_line_id = file_name[:-4]
            #label_text_line = find_textline_by_id(text_line_id,LABEL_DATA_PATH)
            #if len(label_text_line) != 0:  # prevent missing data in ascii(label data)
            #label_text_line_all.append(label_text_line)
                #path informations
            text_line_path = os.path.join(path_1, file_name)
            print(text_line_path)
            e_tree = ET.parse(text_line_path).getroot()
            print(e_tree)
            x_list,y_list,time_stamp = [],[],[]
            x_list,y_list,time_stamp = get_timestamp(e_tree,x_list,y_list,time_stamp)
            #plt.plot(x_list,y_list)
            #plt.show()
            x_list = np.asarray(x_list, dtype=np.float32)
            y_list = np.asarray(y_list, dtype=np.float32)
            x_cor,y_cor,x_min,x_max,y_min,y_max,scale = normalized_x_y(x_list,y_list,e_tree)
            sin_list,cos_list,x_sp_list,y_sp_list,pen_up_list,writing_sin,writing_cos = [],[],[],[],[],[],[]
            for stroke in e_tree.findall('StrokeSet/Stroke'):
                x_point, y_point, time_list = [], [], []
                for point in stroke.findall('Point'):
                    y_point.append(int(point.get('y'))*scale_newy)
                    x_point.append(int(point.get('x'))*scale_newx)
                    if len(time_list) == 0:
                        first_time = float(point.get('time'))
                        time_list.append(0.0)
                    else:
                        time_list.append(float(point.get('time')) - first_time)
                    # calculate cos and sin
                x_point[:], y_point[:] = [(point - x_min) * scale for point in x_point], [(point - y_min) * scale for point in x_point]
                angle_stroke = []
                if len(x_point) < 3:
                    for _ in range(len(x_point)):
                        sin_list += [0]
                        cos_list += [1]
                else:
                    for idx in range(1, len(x_point) - 1):
                        x_prev,y_prev,x_next = x_point[idx - 1],y_point[idx - 1], x_point[idx + 1]
                        y_next, x_now,y_now  = y_point[idx + 1], x_point[idx], y_point[idx]
                        p0,p1,p2 = [x_prev, y_prev],[x_now, y_now],[x_next, y_next]
                        v0,v1 = np.array(p0) - np.array(p1),np.array(p2) - np.array(p1)
                        angle = np.math.atan2(np.linalg.det([v0, v1]), np.dot(v0, v1))
                        angle_stroke.append(angle)
                    new_angle_stroke = [0] + angle_stroke + [0]
                    sin_stroke,cos_stroke = np.sin(new_angle_stroke).tolist(),np.cos(new_angle_stroke).tolist()
                    sin_list += sin_stroke
                    cos_list += cos_stroke
                    # calculate speed
                if len(x_point) < 2:
                    for _ in range(len(x_point)):
                        x_sp_list += [0]
                        y_sp_list += [0]
                    if len(x_point) < 1:
                        exit()
                    x_sp = [0]
                    y_sp = [0]

                else:
                    time_list = np.asarray(time_list, dtype=np.float32)
                    time_list_moved = np.array(time_list)[1:]
                    time_diff = np.subtract(time_list_moved, time_list[:-1])
                    for idx, v in enumerate(time_diff):
                        if v == 0:
                            time_diff[idx] = 0.001
                    x_point_moved, y_point_moved  = np.array(x_point)[1:],np.array(y_point)[1:]
                    x_diff,y_diff = np.subtract(x_point_moved, x_point[:-1]),np.subtract(y_point_moved, y_point[:-1])
                    x_sp, y_sp = np.divide(x_diff, time_diff).tolist(),np.divide(y_diff, time_diff).tolist()
                    x_sp, y_sp = [0] + x_sp, [0] + y_sp
                    x_sp_list += x_sp
                    y_sp_list += y_sp
                    # pen up and down
                pen_up_list = get_pen_up_down(x_point,pen_up_list)
                    # writing direc
                writing_sin,writing_cos = get_writing_direction(x_sp,y_sp,writing_sin,writing_cos)
            time_stamp = np.asarray(time_stamp, dtype=np.float32)
            sin_list, cos_list = np.asarray(sin_list, dtype=np.float32), np.asarray(cos_list, dtype=np.float32)
            x_sp_list, y_sp_list = np.asarray(x_sp_list, dtype=np.float32), np.asarray(y_sp_list, dtype=np.float32)
            pen_up_list = np.asarray(pen_up_list, dtype=np.float32)
            writing_cos, writing_sin = np.asarray(writing_cos, dtype=np.float32), np.asarray(writing_sin, dtype=np.float32)
            text_line_data = np.stack((x_sp_list, y_sp_list, x_cor, y_cor, sin_list, cos_list, writing_sin, writing_cos, pen_up_list, time_stamp), axis=1)
                # (x_cor, y_cor, sin_list, cos_list, time_stamp), axis=1)
                
            temp_length = text_line_data.shape[0]
            text_line_data_all.append(text_line_data)
        #print("Finished a file ", files)
    print(text_line_data_all)
    text_line_data_all = np.array(text_line_data_all)
    #print(text_line_data_all.shape)
    #print(label_text_line_all.shape)

    np.save("data_flipdevice", text_line_data_all)
            

def main():
    FILE_PATH = os.path.dirname(os.path.realpath(__file__))
    STROKES_DATA_PATH = os.path.join(FILE_PATH, "data_flip_device/")
    preprocess(STROKES_DATA_PATH)
    


if __name__ == "__main__":
    main()
